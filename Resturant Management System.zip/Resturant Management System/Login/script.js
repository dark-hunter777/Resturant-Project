 // Initialize a variable to track login status
    let isLoggedIn = false; // This can be managed through a more robust authentication system

    document.getElementById('loginForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the form from submitting normally
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
         // Save the credentials in local storage (for demonstration purposes)
    localStorage.setItem('username', username);
    localStorage.setItem('loggedIn', 'true');

    // Show a message to the user
    alert('You are now logged in as ' + username);
        // Simple validation (you can replace this with your actual authentication logic)
        if (username === 'admin' && password === 'password') {
            isLoggedIn = true; // Set login status to true
            alert('Login successful!'); // Optionally show a success message
            window.location.href = '../index.html'; // Redirect to the main page
        } else {
            document.getElementById('loginMessage').innerText = 'Invalid username or password.';
        }
    });