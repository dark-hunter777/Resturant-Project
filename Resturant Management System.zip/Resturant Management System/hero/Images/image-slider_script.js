document.addEventListener("DOMContentLoaded", function() {
    const quotes = document.querySelectorAll('.quote');
    const images = document.querySelectorAll('.slider-image');
    let currentIndex = 0;

    // Show the first quote and image
    quotes[currentIndex].classList.add('active');
    images[currentIndex].style.display = 'block';

    function showNext() {
        // Hide current quote and image
        quotes[currentIndex].classList.remove('active');
        images[currentIndex].style.display = 'none';

        // Update index
        currentIndex = (currentIndex + 1) % quotes.length;

        // Show next quote and image
        quotes[currentIndex].classList.add('active');
        images[currentIndex].style.display = 'block';
    }

    // Change every 5 seconds
    setInterval(showNext, 5000);
});